from django.db import models

class Admin(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100) 

class Trainer(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)

class DietPlan(models.Model):
    name = models.CharField(max_length=100)
    details = models.TextField()

    def __str__(self):
        return self.name


class Member(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    weight = models.FloatField()
    height = models.FloatField()
    fitness_goal = models.CharField(max_length=255)
    trainer = models.ForeignKey(Trainer, on_delete=models.SET_NULL, null=True, blank=True)

class WorkoutPlan(models.Model):
    name = models.CharField(max_length=100)
    details = models.TextField()
    member = models.ForeignKey(Member, on_delete=models.CASCADE)


    def __str__(self):
        return self.name

    
    


