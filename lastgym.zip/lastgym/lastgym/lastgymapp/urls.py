from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('admin/login/', views.admin_login, name='admin_login'),
    path('trainer/login/', views.trainer_login, name='trainer_login'),
    path('assign_diet/<int:member_id>/', views.assign_diet, name='assign_diet'),
    path('admin/register/', views.admin_registration, name='admin_registration'),
    path('trainer/register/', views.trainer_registration, name='trainer_registration'),
    path('member/register/', views.member_registration, name='member_registration'),
    path('member/login/', views.member_login, name='member_login'),
    path('member/dashboard/<int:member_id>/', views.member_dashboard, name='member_dashboard'),
]