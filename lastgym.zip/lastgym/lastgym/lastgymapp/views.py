from django.shortcuts import render, redirect
from .models import Admin, Trainer, Member, DietPlan, WorkoutPlan
from django.core.mail import send_mail
from django.shortcuts import get_object_or_404
from django.db import IntegrityError

def homepage(request):
    return render(request, 'homepage.html')

def admin_login(request):
    return render(request, 'admin_login.html')

def trainer_login(request):
    return render(request, 'trainer_login.html')

def member_login(request):
    return render(request, 'member_login.html')

def admin_login(request):
    if request.method == 'POST':
        admin_name = request.POST['admin_name']
        admin = Admin.objects.filter(name=admin_name).first()
        if admin:
            trainers = Trainer.objects.all()
            members = Member.objects.all()
            return render(request, 'admin_dashboard.html', {'admin': admin, 'trainers': trainers, 'members': members})
    return render(request, 'admin_login.html')

def trainer_login(request):
    if request.method == 'POST':
        trainer_name = request.POST['trainer_name']
        trainer = Trainer.objects.filter(name=trainer_name).first()
        if trainer:
            members = Member.objects.filter(trainer=trainer)
            return render(request, 'trainer_dashboard.html', {'trainer': trainer, 'members': members})
    return render(request, 'trainer_login.html')

def assign_diet(request, member_id):
    if request.method == 'POST':
        diet_id = request.POST['diet_plan']
        member = Member.objects.get(id=member_id)
        diet_plan = DietPlan.objects.get(id=diet_id)
        member.diet_plan = diet_plan
        member.save()
        return redirect('trainer_dashboard')
    diet_plans = DietPlan.objects.all()
    return render(request, 'assign_diet.html', {'diet_plans': diet_plans})

def admin_registration(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        Admin.objects.create(name=name, email=email, password=password)
        return redirect('admin_login')
    return render(request, 'admin_registration.html')

def trainer_registration(request):
    if request.method == 'POST':
        try:
            new_trainer = Trainer.objects.create(
                name=request.POST['name'],
                email=request.POST['email'],
                password=request.POST['password']
            )
            return redirect('trainer_login')
        except IntegrityError:
            return render(request, 'trainer_registration.html', {'error': 'This email is already registered.'})
    return render(request, 'trainer_registration.html')

def member_registration(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        weight = request.POST['weight']
        height = request.POST['height']
        fitness_goal = request.POST['fitness_goal']
        member = Member.objects.create(
            name=name,
            email=email,
            password=password,
            weight=weight,
            height=height,
            fitness_goal=fitness_goal
        )
        # Send registration email
        send_mail(
            'Welcome to the Fitness App',
            f'Hello {name},\n\nThank you for registering. Your login details are as follows:\n\nEmail: {email}\nPassword: {password}\n\nPlease keep this information safe.\n\nBest regards,\nThe Fitness App Team',
            'noreply@fitnessapp.com',
            [email],
            fail_silently=False,
        )
        return redirect('member_login')
    return render(request, 'member_registration.html')

def member_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        member = Member.objects.filter(email=email, password=password).first()
        if member:
            return redirect('member_dashboard', member_id=member.id)
    return render(request, 'member_login.html')

def member_dashboard(request, member_id):
    member = Member.objects.get(id=member_id)
    return render(request, 'member_dashboard.html', {
        'member': member,
        'trainer': member.trainer,
        'diet_plan': member.diet_plan,
        'workout_plan': member.workout_plan,
        'supplement_link': 'http://example.com/shop'
    })

def trainer_dashboard(request):
    trainer = get_object_or_404(Trainer, id=request.session['trainer_id'])
    members = Member.objects.filter(trainer=trainer)
    diet_plans = DietPlan.objects.all()
    return render(request, 'trainer_dashboard.html', {'trainer': trainer, 'members': members, 'diet_plans': diet_plans})